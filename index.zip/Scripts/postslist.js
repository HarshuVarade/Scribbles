function navigateToPost() {
  location.href = "post.html";
}

const deleteIcons = document.querySelectorAll('.post-trash i');

for (const deleteIcon of deleteIcons) {
  deleteIcon.addEventListener('click', openTrashModal);
}

function openTrashModal(event) {
  const cardId = event.target.closest('.post').id;
  const trashModal = document.querySelector(`#${cardId} .trash-modal`);
  trashModal.style.display = 'block';
}

const closeButtons = document.querySelectorAll('.trash-modal-button-no');

for (const closeButton of closeButtons) {
  closeButton.addEventListener('click', closeTrashModal);
}

function closeTrashModal() {
  const trashModals = document.querySelectorAll('.trash-modal');

  for (const trashModal of trashModals) {
    trashModal.style.display = 'none';
  }
}

function removeCard(cardId) {
  // Get the card element by its ID
  const cardElement = document.getElementById(cardId);

  // Remove the card element from the DOM
  cardElement.parentNode.removeChild(cardElement);
}



const ellipsisIcons = document.querySelectorAll('.post-more i');

for (const ellipsisIcon of ellipsisIcons) {
  ellipsisIcon.addEventListener('click', (event) => {
    const authorElement = event.target.closest('.post').querySelector('.post-username');
    const headingElement = event.target.closest('.post').querySelector('.post-title');
    const contentElement = event.target.closest('.post').querySelector('.post-desc');

    const author = authorElement.textContent;
    const heading = headingElement.textContent;
    const content = contentElement.textContent;

    openPost(author, heading, content);
  });
}



function openPost(author, heading, content) {
  const url = `../Html/post.html?heading=${encodeURIComponent(heading.innerText)}&author=${encodeURIComponent(
          author.innerText)}&content=${encodeURIComponent(content.innerText)}`;
  window.location.href = url;
}
